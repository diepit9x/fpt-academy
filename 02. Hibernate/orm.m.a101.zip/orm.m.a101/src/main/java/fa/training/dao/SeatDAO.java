package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.entities.Seat;
import fa.training.exception.DataAlreadyExistException;
import fa.training.exception.DataNotFoundException;

public interface SeatDAO {
	Seat getSeatByID(int seatId) throws SQLException;
	List<Seat> getAllSeats() throws SQLException;
	boolean updateSeatByID(int seatId, Seat seat) throws SQLException, DataNotFoundException;
	boolean deleteSeatByID(int seatId) throws SQLException, DataNotFoundException;
	boolean insertSeat(Seat seat) throws SQLException, DataAlreadyExistException;
}

package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.entities.CinemaRoom;
import fa.training.exception.DataAlreadyExistException;
import fa.training.exception.DataNotFoundException;

public interface CinemaRoomDAO {
	CinemaRoom getCinemaRoomByID(int cinemaRoomId) throws SQLException;
	List<CinemaRoom> getAllCinemaRooms() throws SQLException;
	boolean updateCinemaRoomByID(int cinemaRoomId, CinemaRoom cinemaRoom) throws SQLException, DataNotFoundException;
	boolean deleteCinemaRoomByID(int cinemaRoomId) throws SQLException, DataNotFoundException;
	boolean insertCinemaRoom(CinemaRoom cinemaRoom) throws SQLException, DataAlreadyExistException;
}

package fa.training.dao;

import java.sql.SQLException;
import java.util.List;

import fa.training.entities.CinemaRoomDetail;
import fa.training.exception.DataAlreadyExistException;
import fa.training.exception.DataNotFoundException;

public interface CinemaRoomDetailDAO {
	CinemaRoomDetail getCinemaRoomDetailByID(int cinemaRoomDetailId) throws SQLException;
	List<CinemaRoomDetail> getAllCinemaRoomDetails() throws SQLException;
	boolean updateCinemaRoomDetailByID(int cinemaRoomDetailId, CinemaRoomDetail cinemaRoomDetail) throws SQLException, DataNotFoundException;
	boolean deleteCinemaRoomDetailByID(int cinemaRoomDetailId) throws SQLException, DataNotFoundException;
	boolean insertCinemaRoomDetail(CinemaRoomDetail cinemaRoomDetail) throws SQLException, DataAlreadyExistException;
}

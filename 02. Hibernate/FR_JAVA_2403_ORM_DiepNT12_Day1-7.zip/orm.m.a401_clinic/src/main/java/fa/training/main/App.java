package fa.training.main;

import org.apache.log4j.Logger;

import fa.training.util.LoggerUtil;

/**
 * Hello world!
 *
 */
public class App 
{
	private static final Logger logger = LoggerUtil.getLogger();
    public static final void main( String[] args )
    {
        logger.error("test logger2");
    }
}
